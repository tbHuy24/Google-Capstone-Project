-- Huy Tran
-- Capstone Project

-- create database
create schema capstone_data_clean; 
use capstone_data_clean;


-- create table to store imported data
create table 202303_tripdata_cleaned (
ride_id varchar(50),
rideable_type varchar(50),
started_at datetime,
ended_at datetime,
start_station_name varchar(100),
start_station_id varchar(50),
end_station_name varchar(100),
end_station_id varchar(50),
start_lat double,
start_lng double,
end_lat double,
end_lng double,
member_casual varchar(50),
ride_length time,
day_of_week int );



-- import csv file from Excel to table
LOAD DATA INFILE '202303-divvy-tripdata-prepared.csv'
INTO TABLE 202303_tripdata_cleaned
FIELDS TERMINATED BY ','
IGNORE 1 LINES;



-- remove duplicated values
DELETE FROM 202303_tripdata_cleaned a
WHERE EXISTS (SELECT * FROM 
						(SELECT *, ROW_NUMBER() OVER(PARTITION BY a.ride_id ORDER BY a.ride_id) AS duplication FROM 202303_tripdata_cleaned a) b 
					   WHERE b.duplication > 1 AND a.ride_id = b.ride_id);



-- fix structural incosistency
UPDATE 202303_tripdata_cleaned
SET start_station_id = REGEXP_REPLACE(start_station_id, '[^0-9]', "" ),
	end_station_id = REGEXP_REPLACE(end_station_id, '[^0-9]', "" );

DELETE FROM 202303_tripdata_cleaned
WHERE LENGTH(start_station_id)  <5 OR LENGTH(end_station_id) <5;

UPDATE 202303_tripdata_cleaned
SET start_station_id = LEFT(start_station_id, 5),
	end_station_id = LEFT(end_station_id, 5);



-- remove outliers
DELETE FROM 202303_tripdata_cleaned a
WHERE EXISTS (SELECT * FROM 
						(SELECT *, (ride_length - AVG(ride_length) Over()) / STD(ride_length) Over()  AS zscore
						 FROM 202303_tripdata_cleaned) b 
					   WHERE (b.zscore > 6 OR b.zscore < -6) AND a.ride_id = b.ride_id)



